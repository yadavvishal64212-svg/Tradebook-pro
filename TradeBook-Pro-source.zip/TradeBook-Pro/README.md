# TradeBook Pro

React + Vite trading journal with a Capacitor Android wrapper.

## Run the web app
1. Install Node.js (LTS).
2. In this folder run `npm install`
3. Run `npm run dev` for local preview, or `npm run build` for production files.

## Android APK
Android Studio and Android SDK/JDK are required.
1. `npm install`
2. `npx cap add android` (first time only)
3. `npm run android:sync`
4. Open the `android` folder in Android Studio, then Build > Build Bundle(s) / APK(s) > Build APK(s).

## Data note
Trades are stored in browser/device localStorage. Export CSV regularly for backup. This starter has no cloud sync or AI analysis and does not provide trading advice.
